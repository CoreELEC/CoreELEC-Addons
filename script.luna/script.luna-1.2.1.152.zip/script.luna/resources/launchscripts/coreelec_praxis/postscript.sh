#!/usr/bin/bash
echo 0 > /sys/class/graphics/fb0/blank