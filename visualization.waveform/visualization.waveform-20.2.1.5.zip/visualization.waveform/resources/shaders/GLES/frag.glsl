#version 100

precision mediump float;

uniform vec4 u_color;

void main()
{
  gl_FragColor = u_color;
}
